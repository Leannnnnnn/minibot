/*
 * pid.h
 *功能：pid控制函数，各个参数版本供参考
 *  Created on: 2021年7月2日
 *      Author: 12249
 */

#ifndef MPU6050_H_
#define MPU6050_H_

#include <Arduino.h>
#include <MPU6050_tockn.h>

void mpu6050_init();//mpu6050初始化
void mpu6050_get_angel(double* getAngel,char Axis); //获取角度，参数例如'X'

#endif /* MPU6050_H_ */
