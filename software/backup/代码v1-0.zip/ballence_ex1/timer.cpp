#include "timer.h"


/***************** 定时中断参数 *****************/
Ticker timer1;  // 中断函数
int timer_flag=0;               //定时器标志；
int interrupt_time = 20;
/***************** 定时中断 *****************/   

void timer1_init()
{
   timer1.attach_ms(interrupt_time, timerIsr);  // 打开定时器中断
   interrupts();                      //打开外部中断 
}



void timerIsr()
{
   timer_flag=1;  //定时时间达到标志      
   //readEncoder();   // 编码器
}
