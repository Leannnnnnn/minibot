/*
 * timer.h
 *功能：定时器中断
 *  Created on: 2022年3月25日
 *      Author: 
 */

#ifndef TIMER_H_
#define TIMER_H_

#include <Arduino.h>
#include <Ticker.h>
#include "moto.h"

void timer1_init();
void timerIsr();

#endif /* TIMER_H_ */
